package com.REG.MTNSIMCARD.Service;

import com.REG.MTNSIMCARD.Models.Client;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.Optional;

public interface ClientService {
    List<Client> findAllClients();
    Client saveclient(Client client);
   Client findClientById(long client);
    //List<Client> findClientById_No(Client client);
    Client updateClient(Client client);
    void deleteClient(Long client);
    Page<Client> pagenateStudent(int pageNo, int pageSize);

}
