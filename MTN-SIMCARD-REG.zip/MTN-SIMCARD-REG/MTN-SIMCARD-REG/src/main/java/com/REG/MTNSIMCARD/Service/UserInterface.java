package com.REG.MTNSIMCARD.Service;

import com.REG.MTNSIMCARD.DataTransferObject.UserRegistartionDto;
import com.REG.MTNSIMCARD.Models.User;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserInterface extends UserDetailsService {
    public User saveAccount(UserRegistartionDto userRegistartionDto);
}
