package com.REG.MTNSIMCARD.imp;
import com.REG.MTNSIMCARD.Models.Client;
import com.REG.MTNSIMCARD.Repository.ClientRepository;
import com.REG.MTNSIMCARD.Service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClientServiceImplementation implements ClientService {

   private  ClientRepository repo;
    private ClientRepository clientRepository;
    @Autowired
    public ClientServiceImplementation(ClientRepository repo, ClientRepository clientRepository) {
        this.repo = repo;
        this.clientRepository = clientRepository;
    }

    @Override
    public List<Client> findAllClients() {
        return repo.findAll();
    }

    @Override
    public Client saveclient(Client client) {
        return repo.save(client);
    }

    @Override
    public Client findClientById(long client) {
        return clientRepository.findById(client);
    }

    public List<Client> findByNid(Long Nid) {
        List<Client> Client1 = repo.findAllById(Nid);

        return Client1 ;
    }


    public List<Client> findClientById_No(Long id) {
        List<Client> listClientById_no = repo.findAll(id);
        return listClientById_no;
    }

    @Override
    public Client updateClient(Client client) {
        return repo.save(client);
    }

    @Override
    public void deleteClient(Long client) {
        clientRepository.deleteById(client);
    }


    @Override
    public Page<Client> pagenateStudent(int pageNo, int pageSize) {
        Pageable pageable= PageRequest.of(pageNo -1,pageSize);
        return this.clientRepository.findAll(pageable);
    }
}
