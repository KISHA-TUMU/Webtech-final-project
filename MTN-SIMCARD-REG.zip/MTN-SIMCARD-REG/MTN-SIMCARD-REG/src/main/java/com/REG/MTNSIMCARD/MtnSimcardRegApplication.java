package com.REG.MTNSIMCARD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MtnSimcardRegApplication {

	public static void main(String[] args) {
		SpringApplication.run(MtnSimcardRegApplication.class, args);
	}

}
