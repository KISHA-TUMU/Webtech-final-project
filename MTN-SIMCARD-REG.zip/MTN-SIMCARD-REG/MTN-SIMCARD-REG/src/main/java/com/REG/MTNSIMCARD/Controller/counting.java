package com.REG.MTNSIMCARD.Controller;

import java.sql.*;

public class counting {
    private Connection connection;

    public counting() throws SQLException {
        // Establish JDBC connection
        String jdbcUrl = "jdbc:postgresql://localhost:5433/tumu";
        String username = "postgres";
        String password = "clairi04";
        connection = DriverManager.getConnection(jdbcUrl, username, password);
    }

    public int countIdenticalIDs(Long idToCount) {
        int count = 0;

        try {
            String query = "SELECT COUNT(*) AS count FROM clients WHERE id_no = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setLong(1, idToCount);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                count = resultSet.getInt("count");
            }

            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(count);

        return count;
    }
}
