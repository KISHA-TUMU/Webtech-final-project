package com.REG.MTNSIMCARD.Repository;
import com.REG.MTNSIMCARD.Models.Contact;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ContactRepository extends JpaRepository<Contact, Long> {
}
