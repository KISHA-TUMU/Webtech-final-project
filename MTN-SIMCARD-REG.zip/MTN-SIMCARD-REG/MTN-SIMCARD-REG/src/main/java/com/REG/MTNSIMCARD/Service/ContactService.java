package com.REG.MTNSIMCARD.Service;


import com.REG.MTNSIMCARD.Models.Contact;

import java.util.List;

public interface ContactService {
    public Contact saveVontact(Contact contact);
        public List<Contact> GetAllContact();
        public void deleteContact(Long delete);
}
