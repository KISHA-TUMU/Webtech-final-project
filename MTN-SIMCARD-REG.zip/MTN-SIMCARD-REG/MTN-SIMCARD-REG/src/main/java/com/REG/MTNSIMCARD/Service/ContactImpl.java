package com.REG.MTNSIMCARD.Service;
import com.REG.MTNSIMCARD.Models.Contact;
import com.REG.MTNSIMCARD.Repository.ContactRepository;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ContactImpl implements ContactService {

    private final ContactRepository contactRepository;

    public ContactImpl(ContactRepository contactRepository) {
        this.contactRepository = contactRepository;
    }

    @Override
    public Contact saveVontact(Contact contact) {
        return contactRepository.save(contact);
    }

    @Override
    public List<Contact> GetAllContact() {
        return contactRepository.findAll();
    }

    @Override
    public void deleteContact(Long id) {
        contactRepository.deleteById(id);
    }
}
