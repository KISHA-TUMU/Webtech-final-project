package com.REG.MTNSIMCARD.Controller;
import com.REG.MTNSIMCARD.Models.Client;
import com.REG.MTNSIMCARD.Repository.ClientRepository;
import com.REG.MTNSIMCARD.imp.ClientServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Controller
public class ClientController {
    ClientServiceImplementation service;

     @Autowired
    public ClientController( ClientServiceImplementation service ) {
        this.service = service;
    }


@GetMapping("/userDashboard")
    public String userDashboard(){
        return "description";
    }

    @GetMapping("/adminDashboard")
    public String adminDashboard(){
        return "adminViewPage";
    }

    @GetMapping("/adminView")
    public String adminViewPage(){
        return "adminViewPage";
    }

    @GetMapping("/delete/{id}")
    public String adminView(@PathVariable("id") @Validated Long id) {
        service.deleteClient(id);
        return "redirect:/clients";
    }

    @GetMapping("/clients")
    public String listClients(Model model) {
        return findPaginated(1,model);
    }
    @GetMapping ("/search")
    public String searchMethod(Model model){
        model.addAttribute("search",new Client());
        return "findOne";
    }
    @PostMapping("/search")
    public String getClients(@ModelAttribute("search") @Validated Client client,@RequestParam("idNo") String idNo,Model model){
       Long id=Long.parseLong(idNo);
       System.out.println(id);
        List<Client> client1=service.findClientById_No(id);
        if (client1!=null && !client1.isEmpty()) {
            model.addAttribute("client1",client1);
            return "findOne";
        }else {
            model.addAttribute("error","He/She is not found");
        }
        return "redirect:/search?error";
    }

    @GetMapping("/clients/nem")
    public String creatClientForm(Model model) {
        Client client = new Client();
        model.addAttribute("client", client);
        return "clients-create";
    }

    @GetMapping("/client/new")
    public String getClientRegisterForm(Model model) {
        Client client = new Client();
        model.addAttribute("client", client);
        model.addAttribute("pageTitle", "Register Here");
        return "clientRegisterForm";
    }

    @PostMapping("/client/save")
    public String registerClient(@ModelAttribute("client") @Validated Client client, Model model, RedirectAttributes ra, @RequestParam("id_no") String id,BindingResult result) throws SQLException {
        counting count=new counting();
        Long ids=Long.parseLong(id);
           System.out.println(ids);

           client.setIdNo(ids);

        int numberOfRegistrations = count.countIdenticalIDs(ids);
        System.out.println(numberOfRegistrations);
        try {
            int maxRegistrations = 3;

            if (numberOfRegistrations < maxRegistrations) {

                Client savedClient = service.saveclient(client);
                model.addAttribute("client", savedClient);
                ra.addFlashAttribute("message", "Client registered successfully");
            } else {
                ra.addFlashAttribute("message", "The maximum number of registrations for this ID has been reached. Please try another ID.");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return "redirect:/client/new";
    }


    @GetMapping("/edit/{id}")
    public String edituser(@PathVariable("id") Long id, Model model) {
        Client client = service.findClientById(id);
        model.addAttribute("client", client);
        return "EditClient";
    }
    @PostMapping("/edit/{id}")
    public String UpdateUser(@PathVariable("id") Long id, @ModelAttribute("client") @Validated Client client, BindingResult result){
        client.setId(id);
        service.updateClient(client);
        return "redirect:/clients";
    }

    @GetMapping("/page/{pageNo}")
    public String findPaginated(@PathVariable(value = "pageNo") int pageNo,Model model){
        int pageSize=5;
        Page<Client> page=service.pagenateStudent(pageNo,pageSize);
        List<Client> clientList=page.getContent();

        model.addAttribute("currentPage",pageNo);
        model.addAttribute("totalPage",page.getTotalPages());
        model.addAttribute("totalItems",page.getTotalElements());
        model.addAttribute("clientList",clientList);
        return "clients-list";
    }
    @GetMapping("/userDetail")
    public String userView(Model model){
        model.addAttribute("search",new Client());
        return "userDetails";
    }

    @PostMapping("/userDetail")
    public String userVie(@ModelAttribute("search") @Validated Client client,@RequestParam("idNo") String idNo,Model model){
        Long id=Long.parseLong(idNo);
        System.out.println(id);
        List<Client> client1=service.findClientById_No(id);
        if (client1!=null && !client1.isEmpty()) {
            model.addAttribute("client1",client1);
            return "userDetails";
        }else {
            model.addAttribute("error","He/She is not found");
        }
        return "redirect:/userDetail?error";
    }
}
